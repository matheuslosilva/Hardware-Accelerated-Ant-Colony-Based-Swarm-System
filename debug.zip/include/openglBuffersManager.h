#ifndef OPENGLBUFFERSMANAGER_H
#define OPENGLBUFFERSMANAGER_H

#include<antColony.h>


using namespace std;

class OpenglBuffersManager
{
	
	public:
		Shader* shaderAnts;

		Shader* shaderPheromone;

		VAO VAOAnts;
    
	    VBO AntsMatricesBuffer;

	    VAO VAOPheromone;
	    
	    GLbitfield* pixelMap;    


	  public:
		OpenglBuffersManager(AntColony* antColony);

		VBO createAntsComponents(VAO VAOAnts, glm::mat4* antsModelMatrices);

		void createTextureBuffer();
		void createPixelBuffers();
		VAO createPheromoneComponents();
};

#endif