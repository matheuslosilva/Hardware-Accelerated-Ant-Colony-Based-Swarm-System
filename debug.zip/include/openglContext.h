#ifndef OPENGLCONTEXT_H
#define OPENGLCONTEXT_H

#include <constants.h>

class OpenglContext
{
	public:
		GLFWwindow*  init();
		void processInput(GLFWwindow *window);
};



#endif
